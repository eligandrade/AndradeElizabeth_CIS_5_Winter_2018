/* 
 * File:   main.cpp
 * Author: Elizabeth Andrade
 * Created on January 2, 2018, 12:30 PM
 * Purpose: First Program Hello World
 */

//System Libraries
#include <iostream>
using namespace std;

int main(int argc, char** argv) {
    cout<<"Hello World"<<endl;
    return 0;
}